
#ifndef BLOCK_SOLVER_EXAMPLE_H
#define BLOCK_SOLVER_EXAMPLE_H

class CommonExampleInterface* BlockSolverExampleCreateFunc(struct CommonExampleOptions& options);

#endif  //BLOCK_SOLVER_EXAMPLE_H
